module.exports = async function (uriConnect) {
	const mongoose = require("mongoose");

	// Fix deprecation warning
	mongoose.set('strictQuery', false);

	const threadModel = require("../models/mongodb/thread.js");
	const userModel = require("../models/mongodb/user.js");
	const dashBoardModel = require("../models/mongodb/userDashBoard.js");
	const globalModel = require("../models/mongodb/global.js");
	const bankModel = require("../models/mongodb/bank.js");
	const staiHistoryModel = require("../models/mongodb/staiHistory.js");

	await mongoose.connect(uriConnect, {
		useNewUrlParser: true,
		useUnifiedTopology: true
	});

	return {
		threadModel,
		userModel,
		dashBoardModel,
		globalModel,
		bankModel,
		staiHistoryModel
	};
};