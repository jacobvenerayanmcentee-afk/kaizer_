const fs = require('fs');

module.exports = {
  config: {
    name: "file",
    version: "2.0",
    author: "Kaizer",
    countDown: 2,
    role: 2, // Only bot admin
    shortDescription: "Send bot script file",
    longDescription: "Send the content of a specified bot script file",
    category: "owner"},

  onStart: async function ({ message, args, api, event, usersData }) {
    const { threadID, senderID, messageID } = event;
    
    // Bot Admin check
    const botAdmins = (global.GoatBot.config?.adminBot || []).map(String);
    if (!botAdmins.includes(String(senderID))) {
      return api.sendMessage("⛔ You are not authorized to use this command.", threadID, messageID);
    }

    const fileName = args[0];
    if (!fileName) {
      return api.sendMessage("⚠️ Please provide a file name.\nExample: .file index", threadID, messageID);
    }

    const filePath = __dirname + `/${fileName}.js`;
    if (!fs.existsSync(filePath)) {
      return api.sendMessage(`❌ File not found: ${fileName}.js`, threadID, messageID);
    }

    const fileContent = fs.readFileSync(filePath, 'utf8');
    api.sendMessage({ body: `📂 Content of ${fileName}.js:\n\n${fileContent}` }, threadID);
  }
};
